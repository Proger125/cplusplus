#include <cmath>
#include <iostream>
#include <vector>
#include <fstream>
#include "Containers.h"
#include "Shared_ptr.h"
#include "Stack.h"

using namespace std;

int main() {

  system("pause");
  return 0;
}