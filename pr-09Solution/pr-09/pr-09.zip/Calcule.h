#pragma once
#include <cmath>
#include <iostream>
#include <vector>

using namespace std;
int priority_f(string s) {
  if (s == "|") {
    return 2;
  }
  if (s == "max" || s == "min") {
    return 1;
  }
}
vector<string> ToReversePolishForm() {
  vector<string> result;
  string str, num = "", f = "";
  stackInList<string> stack;
  getline(cin, str);
  for (int i = 0; i < str.size(); i++) {
    if ((str[i] >= '0' && str[i] <= '9') || str[i] == '.') {
      num += str[i];
      continue;
    }
    if (str[i] == '(') {
      result.push_back(num);
      num = "";
      stack.push(f);
      f = "";
      continue;
    }
    if (str[i] == ')') {
      result.push_back(num);
      num = "";
      result.push_back(stack.pop());
      continue;
    }
    if (str[i] == ',') {
      result.push_back(num);
      num = "";
      continue;
    }
    if (str[i] >= 'a' && str[i] <= 'z') {
      f += str[i];
      continue;
    }
    if (str[i] == '|') {
      string a;
      a += '|';
      stack.push(a);
	}
  }
  while (!stack.IsEmpty()) {
    result.push_back(stack.pop());
  }
  int i = 0;
  while (i < result.size()) {
    if (result[i] == "") {
      result.erase(result.begin() + i, result.begin() + i + 1);
      i--;
    }
    i++;
  }
  return result;
}
int CalculateForm(vector<string> v) {
  stackInList<string> stack;
  int result = 0;
  for (int i = 0; i < v.size(); i++) {
    if (v[i] != "max" && v[i] != "min" && v[i] != "|") {
      stack.push(v[i]);
    } else {
      int first = stoi(stack.pop());
      int second = stoi(stack.pop());
      stack.push(to_string(first | second));
    }
  }
  return stoi(stack.pop());
}