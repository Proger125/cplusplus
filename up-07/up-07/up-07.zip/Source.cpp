#include "Header.h"

int main() {
  Program myprog;
  system("pause");
  return 0;
}