#include "Containers.h"
#include "Point.h"
#include "Programm.h"
#include "Shape.h"

int main() { return Programm::Main(); }